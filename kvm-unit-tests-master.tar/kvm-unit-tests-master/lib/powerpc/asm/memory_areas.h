#ifndef _ASMPOWERPC_MEMORY_AREAS_H_
#define _ASMPOWERPC_MEMORY_AREAS_H_

#include <asm-generic/memory_areas.h>

#endif

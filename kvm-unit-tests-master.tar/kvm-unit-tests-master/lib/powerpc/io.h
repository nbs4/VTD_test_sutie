/*
 * Prototypes for io.c
 *
 * This work is licensed under the terms of the GNU GPL, version 2.
 */

#ifndef _POWERPC_IO_H_
#define _POWERPC_IO_H_

extern void io_init(void);
extern void putchar(int c);

#endif

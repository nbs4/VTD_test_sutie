#ifndef _ASMARM_MEMORY_AREAS_H_
#define _ASMARM_MEMORY_AREAS_H_

#include <asm-generic/memory_areas.h>

#endif

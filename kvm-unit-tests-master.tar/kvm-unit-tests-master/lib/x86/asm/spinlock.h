#ifndef _ASMX86_SPINLOCK_H_
#define _ASMX86_SPINLOCK_H_

#include <asm-generic/spinlock.h>

#endif

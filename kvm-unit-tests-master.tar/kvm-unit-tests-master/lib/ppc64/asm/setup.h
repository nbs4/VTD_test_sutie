#include "../../powerpc/asm/setup.h"

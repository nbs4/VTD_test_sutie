#include "../../powerpc/asm/rtas.h"

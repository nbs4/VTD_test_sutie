#ifndef X86_IORAM_H
#define X86_IORAM_H

#define IORAM_BASE_PHYS 0xff000000UL
#define IORAM_LEN       0x10000UL

#endif
